Delhi Urban Atlas | 1995–2025

Upload all extracted files to the repository root. Enable GitHub Pages from main / root. Open index.html locally to preview. All original GeoTIFFs, PDF and CSV downloads are retained. Map display is generated from original pixel-query data.
